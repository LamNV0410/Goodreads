﻿namespace SMD.Goodreads.API.Models.Requests
{
    public class BookModelRequest
    {
        public string Name { get; set; }
    }
}
