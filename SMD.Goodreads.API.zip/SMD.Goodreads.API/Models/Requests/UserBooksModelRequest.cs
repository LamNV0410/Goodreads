﻿namespace SMD.Goodreads.API.Models.Requests
{
    public class UserBooksModelRequest
    {
        public bool? IsCompleted { get; set; }
    }
}
