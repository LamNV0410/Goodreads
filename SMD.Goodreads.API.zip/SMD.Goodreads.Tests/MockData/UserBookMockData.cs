﻿using SMD.Goodreads.API.Models.Entities;
using System.Net;

namespace SMD.Goodreads.Tests.MockData
{
    public class UserBookMockData
    {
        public static List<Book> GetUserBooksCompletedReading(int userId)
        {
            return BookData().Where(_ => _.UserBooks.Any(x => x.IsCompleted && x.UserId == userId)).ToList();
        }
        public static List<Book> BookData()
        {
            return new List<Book>()
            {
                new Book()
                {
                   Id = 1,
                   Name="Coven",
                   Description= @"
Emsy has always lived in sunny California, 
and she'd much rather spend her days surfing with her friends or hanging out with her girlfriend than honing her powers as a fire elemental.
But when members of her family's coven back east are murdered under mysterious circumstances that can only be the result of powerful witchcraft, 
her family must suddenly return to dreary upstate New York. There, Emsy will have to master her neglected craft in order to find the killer . . . 
before her family becomes their next target",
                   UserBooks = new List<UserBook>()
                   {
                       new UserBook()
                       {
                            BookId = 1,
                            IsCompleted = true,
                            UserId = 1
                       }
                   }
        },
                new Book()
                {
                   Id = 2,
                   Name="My Favorite Thing Is Monsters, Vol. 2",
                   Description= @"In the conclusion of this two-part graphic novel, 
set in 1960s Chicago, dark mysteries past and present abound, and 10-year-old Karen tries to solve them.
\r\n\r\nKaren attends the Yippie-organized Festival of Life in Chicago, and finds herself swept up in a police stomping. 
Privately, she wrestles with her sexual identity, and she continues to investigate her neighbor’s recent death. 
She discovers one last cassette tape, which sheds light on Anka’s heroic activities.",
                   UserBooks = new List<UserBook>()
                   {
                       new UserBook()
                       {
                            BookId = 2,
                            IsCompleted = true,
                            UserId = 1
                       }
                   }
                }
            };
        }
        public static UserBook GetUserBook()
        {
            return new UserBook()
            {
                BookId = 2,
                IsCompleted = true,
                UserId = 2
            };
        }
        public static UserBook NewUserBook()
        {
            return new UserBook()
            {
                BookId = 2,
                IsCompleted = true,
                UserId = 3
            };
        }
        public static UserBook GetEmptyUserBook()
        {
            return null;
        }
    }
}
